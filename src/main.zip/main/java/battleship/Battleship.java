package battleship;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Battleship extends JFrame implements ActionListener {

    private Board mGameBoard;
    private JButton mShowShipsButton, mStartNewGameButton;

    public Battleship(String title, Board gameBoard) throws HeadlessException {
        super(title);
        this.mGameBoard = gameBoard;
        this.add(gameBoard);

        mStartNewGameButton = new JButton("Start New Game");
        mStartNewGameButton.setBounds(50,10,80,30);
        mStartNewGameButton.setBackground(Color.WHITE);
        mStartNewGameButton.addActionListener(this);
        this.add(mStartNewGameButton);

        mShowShipsButton = new JButton("Show Battleships");
        mShowShipsButton.setBounds(150,10,80,30);
        mShowShipsButton.setBackground(Color.WHITE);
        mShowShipsButton.addActionListener(this);
        this.add(mShowShipsButton);

        this.setSize(400,400);
        this.setLayout(null);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Logger log = Logger.getLogger(Battleship.class.getSimpleName());
        if (e.getSource().equals(mShowShipsButton)) {
            log.log(Level.ALL, "show ship clicked");
        } else if (e.getSource().equals(mStartNewGameButton)) {
            log.log(Level.ALL, "start new game clicked");
        }
    }

    public static void main(String[] args) {
        Board framePanel = new Board();
        framePanel.setBounds(80,160,400,400);
        Battleship applicationFrame = new Battleship("Battleship", framePanel);
        applicationFrame.show();
    }
}
